/*
* © Copyright 2023 Mitryguardians
* Version : 1.0.0
* GitHub : Mitryguardians
*/

retru = extension.page.getElementByXpath("/html/body/div[2]/main/ol/li[6]")
retru.style = "background: transparent !important;"

tiez = extension.page.getElementByXpath("/html/body/div[2]/main/div[2]/div/div/div/div/div/div[1]/a[1]/div/span[2]")
tiez.style = "color: var(--text-color) !important;"

frz = extension.page.getElementByXpath("/html/body/div[4]/div[1]/div/table")
frz.style = "background: #000000;"
