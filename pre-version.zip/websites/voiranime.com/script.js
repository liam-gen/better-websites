/* Mitryguardians
* Version : 1.0.0
* GitHub : Mitryguardians
*/
// searchOne = extension.page.getElementByXpath("/html/body/div[1]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div/div[1]/div/div[1]/div/div[3]/form/input[1]")
// searchOne.className = "tryu"