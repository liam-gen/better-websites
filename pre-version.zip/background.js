chrome.contextMenus.create({ id: "bw-settings", title: "Better Websites"});
chrome.contextMenus.create({ id: "bw-page-settings", title: "Paramètres généraux", parentId: "bw-settings"});
chrome.contextMenus.create({ id: "bw-custom-settings", title: "Paramètres du site", parentId: "bw-settings"});

chrome.contextMenus.onClicked.addListener(function(e, t){
    if(e.menuItemId == "bw-page-settings"){
        chrome.tabs.sendMessage(t.id, "bw-settings", function(response) {});
    }

    if(e.menuItemId == "bw-custom-settings"){
        chrome.tabs.sendMessage(t.id, "bw-custom-settings", function(response) {});
    }
})