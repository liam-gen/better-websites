/*
 * © Copyright 2023 Better Websites
 * File version : 1.0.2-1
 * File author : liamgen.js
 * Informations : DO NOT TOUCH THIS FILE !
*/

class Extension{
    constructor(){
        this.page = new Page()
        this.modals = new Modals(this)
        this.href = document.querySelector("script[ext]").getAttribute("ext")
        this.settings = {}
        this.customSettings = {}
        this.hasCustomSettings = false
    }

    utf8(text){
        try{
            return decodeURIComponent(escape(text))
        }catch(e){
            return text
        }
    }

    getURL(){
        return document.querySelector("script[ext]").getAttribute("ext")
    }

    getCustomSetting(id){
        let value = localStorage.getItem("bw-cs-"+id) ? localStorage.getItem("bw-cs-"+id) : this.customSettings[id].default
        if(value == "true"){
            value = true
        }
        else if(value == "false"){
            value = false
        }
        return value
    }

    setCustomSettings(settings){
        this.customSettings = settings
        this.hasCustomSettings = true
    }

    openCustomSettings(){
        const container = document.createElement("div")

        const content = document.createElement("div")
        content.style = "text-align: left !important;"
        const settings = this.customSettings

        Object.keys(settings).forEach((k) => {
            let s = settings[k]

            let span = document.createElement("span")
            span.innerHTML = s.title

            let input = document.createElement("input")
            input.setAttribute("type", s.type)
            if(s.type == "checkbox"){
                let statut = extension.getCustomSetting(k) ? "checked" : "unchecked"
                input.style.margin = "10px"
                input.setAttribute(statut, "")
                input.id = "bw-cs-set-"+k
                content.appendChild(input)
                content.appendChild(span)
            }
            else {
                let value = localStorage.getItem("bw-cs-"+k) ? localStorage.getItem("bw-cs-"+k) : s.default
                input.setAttribute("value", value)
                input.id = "bw-cs-set-"+k
                content.appendChild(span)
                content.appendChild(document.createElement("br"))
                content.appendChild(input)
            }
            content.appendChild(document.createElement("br"))

            container.appendChild(content)
            
        })

        

            Swal.fire({
                title: extension.utf8('Paramètres du site'),
                html: extension.utf8(container.innerHTML),
                showDenyButton: true,
                showCancelButton: false,
                confirmButtonText: 'Sauvegarder',
                denyButtonText: `Annuler`,
              }).then((result) => {
                if (result.isConfirmed) {
                    Object.keys(settings).forEach((k) => {
                        let v = settings[k]
                        let value;
                        if(v.type == "checkbox"){
                            value = document.getElementById("bw-cs-set-"+k).checked
                        }else{
                            value = document.getElementById("bw-cs-set-"+k).value
                        }
                        localStorage.setItem("bw-cs-"+k, value)
                        
                    })
                    location.reload()
                } else if (result.isDenied) {
                  return
                }
              })
    }

    openSettings(){
        let fonts;

                try{
                    var xmlHttp = new XMLHttpRequest();
                    xmlHttp.open( "GET", this.href+"assets/fonts.json", false );
                    xmlHttp.send( null );
                    fonts = JSON.parse(xmlHttp.responseText).sort()
                }
                catch(e){
                    fonts = []
                }

                let container = document.createElement("div")

                let font_input = document.createElement("select")
                font_input.style = "color: black !important"
                font_input.id = "better-settings-font"

                fonts.forEach(v => {
                    let e = document.createElement("option")
                    e.value = v
                    e.innerHTML = v
                    e.style.fontFamily = v
                    if(localStorage.getItem("better-settings-font") == v){
                        e.setAttribute("selected", "")
                        font_input.style.fontFamily = v
                    }
                    e.style.color = "black"
                    font_input.appendChild(e)
                })

                font_input.setAttribute("onchange", `document.getElementById("better-settings-font").style.fontFamily = document.getElementById("better-settings-font").value`)
                container.appendChild(font_input)

                let after = "";

                if(this.hasCustomSettings){

                    let div = document.createElement("div")
                    let button = document.createElement("button")

                    button.id = "bw-open-custom-settings-"+Math.floor(Math.random() * 9999999)

                    this.page.waitElement("#"+button.id).then(e => {
                        e.onclick = function(){
                            extension.openCustomSettings()
                        }
                    })
                    button.innerHTML = "Paramètres du site"
                    button.className = "bw-nobtn bw-btn"
                    button.style = "border: solid .1px gray !important;"

                    div.appendChild(button)

                    after = div.innerHTML
                }



                Swal.fire({
                    title: this.utf8('Better Websites - Paramètres'),
                    html: this.utf8(`<div style="color: black !important"><input style="color: black !important" style="transform: scale(1.5)" type="checkbox" id="better-settings-load" ${localStorage.getItem("better-settings-load") == "true" || localStorage.getItem("better-settings-load") == "" ? "checked" : "unchecked"}>&nbsp;&nbsp;<span style="color: black !important">Modifier le style du site</span></div><div style="color: black !important"><span style="color: black !important">Utiliser un fond personnalisé</span><br><input style="color: black !important" style="width: 90%" type="text" id="better-settings-background" class="better-settings-input" value="${localStorage.getItem("better-settings-background") == "null" ? "" : localStorage.getItem("better-settings-background")}"></div><div style="color: black !important"><span style="color: black !important">Modifier la couleur du texte</span><br><input style="color: black !important" type="color" id="better-settings-text-color" value="${localStorage.getItem("better-settings-text-color") || "#FFFFFF"}"><br><br><input style="color: black !important" style="transform: scale(1.5)" type="checkbox" id="better-settings-editable" ${localStorage.getItem("better-settings-editable") == "true" || localStorage.getItem("better-settings-editable") == "" ? "checked" : "unchecked"}>&nbsp;<span style="color: black !important">Rendre le contenu modifiable</span><br><br><span style="color: black !important">Choisir la police</span><br>${container.innerHTML}<br><br>${after}</div>`),
                    showDenyButton: true,
                    showCancelButton: false,
                    confirmButtonText: 'Sauvegarder',
                    denyButtonText: `Annuler`,
                  }).then((result) => {
                    if (result.isConfirmed) {
                        this.modals.setSettings()
                    } else if (result.isDenied) {
                      return
                    }
                  })
            }
}

class Page{
    getElementByXpath(path) {
        return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    }

    exists(element){
        return new Promise((res, rej) => {
            this.elementExist(element) ? res(element) : rej()
        })
    }

    waitElement(selector) {
        return new Promise(resolve => {
            if (document.querySelector(selector)) {
                return resolve(document.querySelector(selector));
            }
    
            const observer = new MutationObserver(mutations => {
                if (document.querySelector(selector)) {
                    resolve(document.querySelector(selector));
                    observer.disconnect();
                }
            });
    
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });
    }

    insertCSS(css, where="beforeend"){
        document.body.insertAdjacentHTML(where, "<style>"+css+"</style>");
    }

    elementExist(element){
        return typeof(element) != 'undefined' && element != null
    }

    insertHTML(html, where="beforeend"){
        document.body.insertAdjacentHTML(where, html);
    }

    loadScript(src){
        let url = document.querySelector("script[ext]").getAttribute("ext")
        const script = document.createElement('script');
        script.setAttribute("src", url+src);
        document.body.appendChild(script)
    }

    insertStylesheet(src){
        let url = document.querySelector("script[ext]").getAttribute("ext")
        const style = document.createElement('link');
        style.href = url+src
        style.rel = "stylesheet"
        document.head.appendChild(style)
    }
}

class Modals{
    constructor(ext){
        this.ext = ext
    }

    createModal(title, html, callback){
        Swal.fire({
            title: extension.utf8(title),
            html: extension.utf8(html),
            showDenyButton: false,
            showCancelButton: false,
          }).then(callback)
    }

    setSettings(){
        localStorage.setItem('better-settings-load', document.getElementById("better-settings-load").checked)
        localStorage.setItem("better-settings-background", document.getElementById("better-settings-background").value)
        localStorage.setItem("better-settings-text-color", document.getElementById("better-settings-text-color").value)
        localStorage.setItem("better-settings-editable", document.getElementById("better-settings-editable").checked)
        localStorage.setItem("better-settings-font", document.getElementById("better-settings-font").value)
        location.reload()
    }
}

const extension = new Extension()